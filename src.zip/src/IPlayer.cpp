#include "IPlayer.h"

IPlayer::IPlayer(const PlayerTypes player_type) :
	m_player_type(player_type)
{}
